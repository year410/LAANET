######################################################################################
#LEDNet: A Lightweight Encoder-Decoder Network for Real-Time Semantic Segmentation
#Paper-Link: https://arxiv.org/abs/1905.02423
######################################################################################


import torch
import torch.nn as nn
import torch.nn.functional as F
from reformer_pytorch import LSHSelfAttention



__all__ = ["LEDNet"]

def Split(x):
    c = int(x.size()[1])
    c1 = round(c * 0.5)
    x1 = x[:, :c1, :, :].contiguous()
    x2 = x[:, c1:, :, :].contiguous()
    return x1, x2 


def Merge(x1,x2):
    return torch.cat((x1,x2),1) 
    


class PermutationBlock(nn.Module):
    def __init__(self, groups):
        super(PermutationBlock, self).__init__()
        self.groups = groups

    def forward(self, input):
        n, c, h, w = input.size()
        G = self.groups
        output = input.view(n, G, c // G, h, w).permute(0, 2, 1, 3, 4).contiguous().view(n, c, h, w)
        return output



class Conv2dBnRelu(nn.Module):
    def __init__(self,in_ch,out_ch,kernel_size=3,stride=1,padding=0,dilation=1,bias=True):
        super(Conv2dBnRelu,self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch,out_ch,kernel_size,stride,padding,dilation=dilation,bias=bias),
            nn.BatchNorm2d(out_ch, eps=1e-3),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.conv(x)


class DownsamplerBlock(nn.Module):
    def __init__(self, ninput, noutput):
        super().__init__()

        self.conv = nn.Conv2d(ninput, noutput-ninput, (3, 3), stride=2, padding=1, bias=True)
        self.pool = nn.MaxPool2d(2, stride=2)
        self.bn = nn.BatchNorm2d(noutput, eps=1e-3)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, input):
        x1 = self.pool(input)
        x2 = self.conv(input)

        diffY = x2.size()[2] - x1.size()[2]
        diffX = x2.size()[3] - x1.size()[3]

        x1 = F.pad(x1, [diffX // 2, diffX - diffX // 2,
                        diffY // 2, diffY - diffY // 2])

        output = torch.cat([x2, x1], 1)
        output = self.bn(output)
        output = self.relu(output)
        return output


class ConvBNReLU(nn.Module):
    def __init__(self, in_chan, out_chan, ks=3, stride=1, padding=1, *args, **kwargs):
        super(ConvBNReLU, self).__init__()
        self.conv = nn.Conv2d(in_chan,
                out_chan,
                kernel_size = ks,
                stride = stride,
                padding = padding,
                bias = False)
        # self.bn = BatchNorm2d(out_chan)
        self.bn = nn.BatchNorm2d(out_chan)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x 

class eca_layer(nn.Module):
    """Constructs a ECA module.
    Args:
        channel: Number of channels of the input feature map
        k_size: Adaptive selection of kernel size
    """
    def __init__(self, channel, k_size=5):
        super(eca_layer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=k_size, padding=(k_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # feature descriptor on the global spatial information
        y = self.avg_pool(x)

        # Two different branches of ECA module
        y = self.conv(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)

        # Multi-scale information fusion
        y = self.sigmoid(y)
        out = x + x * y.expand_as(x)
        return out

class Conv(nn.Module):
    def __init__(self, nIn, nOut, kSize, stride, padding, dilation=(1, 1), groups=1, bn_acti=False, bias=False):
        super().__init__()

        self.bn_acti = bn_acti

        self.conv = nn.Conv2d(nIn, nOut, kernel_size=kSize,
                              stride=stride, padding=padding,
                              dilation=dilation, groups=groups, bias=bias)

        if self.bn_acti:
            self.bn_prelu = BNPReLU(nOut)

    def forward(self, input):
        output = self.conv(input)

        if self.bn_acti:
            output = self.bn_prelu(output)

        return output


class FEM_A(nn.Module):
    def __init__(self, nIn, dropprob, d):
        super().__init__()

#        oup_inc = chann//2

        self.bn_relu_1 = BNPReLU(nIn)
        self.conv3x3 = Conv(nIn, nIn // 2, 3, 1, padding=1, bn_acti=True)
        self.dconv3x1 = Conv(nIn // 2, nIn // 2, (3, 1), 1, padding=(1, 0), groups=nIn // 2, bn_acti=True)
#        self.dconv3x1 = nn.Conv2d(nIn // 2, nIn // 2, (3, 1), 1, padding=(1, 0), groups=nIn // 2)
        self.dconv1x3 = Conv(nIn // 2, nIn // 2, (1, 3), 1, padding=(0, 1), groups=nIn // 2, bn_acti=True)
        self.ddconv3x1 = nn.Conv2d(nIn // 2, nIn // 2, (3, 1), 1, padding=(1 * d, 0), dilation=(d, 1), groups=nIn // 2)
        self.ddconv1x3 = Conv(nIn // 2, nIn // 2, (1, 3), 1, padding=(0, 1 * d), dilation=(1, d), groups=nIn // 2, bn_acti=True)
        
        self.convd = nn.Conv2d(nIn // 2, nIn // 2, 3, 1, padding=d, dilation=d, groups=nIn // 2)
        self.convp = Conv(nIn // 2, nIn, 1, 1, padding=0, bn_acti=True)
#        self.convp = nn.Conv2d(nIn // 2, nIn, 1, 1)
        self.prelu = nn.PReLU(nIn // 2)
        self.eca = eca_layer(nIn)
        self.bn_relu_2 = BNPReLU(nIn // 2)
        self.dropout = nn.Dropout2d(dropprob)

        # self.channel_shuffle = PermutationBlock(2)
       
    
    def forward(self, input):
        output = self.bn_relu_1(input)
        output = self.conv3x3(output)

        br1 = self.dconv3x1(output)
#        br1 = self.prelu(br1)
#        br1 = self.dconv1x3(br1)
        
        br2 = self.ddconv3x1(output)
        br2 = self.prelu(br2)
        br2 = self.ddconv1x3(br2)

        out = br1 + br2
#        out = self.bn_relu_2(out)
        out = self.convd(out)
        out_ = self.convp(out)
        
        out_ = self.eca(out_)
        if (self.dropout.p != 0):
            out_ = self.dropout(out_)

        out_put = input + out_
        
        return out_put


        # return    ### channel shuffl

class ChannelAttention(nn.Module):
    def __init__(self, in_planes, rotio=8):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.sharedMLP = nn.Sequential(
            nn.Conv2d(in_planes, in_planes // rotio, 1), nn.ReLU(), 
            ConvBNReLU(in_planes // rotio, in_planes, 1, 1, 0))

        self.sigmoid = nn.Sigmoid()
    def forward(self, x):
        avgout = self.avg_pool(x)
        maxout = self.max_pool(x)
        att_ = self.sharedMLP(avgout + maxout)
        att = self.sigmoid(att_)
        out = x * att
        return out

class SpatialAttention(nn.Module):
    def __init__(self, in_chan, out_chan, inplane, midplane, bias=False):
        super(SpatialAttention, self).__init__()
        self.convbnrelu = ConvBNReLU(in_chan, out_chan, 3, 1, 1)
#        self.convbnrelu1 = ConvBNReLU(4, 2, 3, 1, 1)
#        self.convbnrelu2 = ConvBNReLU(2, 1, 3, 1, 1)
        self.conv1 = nn.Sequential(
            ConvBNReLU(4, 2, 3, 1, 1),
            ConvBNReLU(2, 1, 3, 1, 1))
        self.conv2 = ConvBNReLU(inplane, midplane, 1, 1, 0)
        self.ca = ChannelAttention(midplane, rotio=8)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x, y):
        h, w = x.size()[2:]
        size = (h, w)
        y = F.interpolate(y, size=size, mode='bilinear', align_corners=True)
        x_ = self.conv2(x)
        x_ = self.ca(x_)
        avg_outx = torch.mean(x_, dim=1, keepdim=True)
        max_outx, _ = torch.max(x_, dim=1, keepdim=True)
        avg_outy = torch.mean(y, dim=1, keepdim=True)
        max_outy, _ = torch.max(y, dim=1, keepdim=True)
        att = torch.cat([avg_outx, max_outx, avg_outy, max_outy], dim=1)
        att = self.conv1(att)
        atten = self.sigmoid(att)
        out = x_ * atten + y * (1 - atten)
        out = self.convbnrelu(out)
        return out

class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super(h_sigmoid, self).__init__()
        self.relu = nn.ReLU6(inplace=inplace)

    def forward(self, x):
        return self.relu(x + 3) / 6

class h_swish(nn.Module):
    def __init__(self, inplace=True):
        super(h_swish, self).__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)

    def forward(self, x):
        return x * self.sigmoid(x)




class InputInjection(nn.Module):
    def __init__(self, ratio):
        super().__init__()
        self.pool = nn.ModuleList()
        for i in range(0, ratio):
            self.pool.append(nn.AvgPool2d(3, stride=2, padding=1))

    def forward(self, input):
        for pool in self.pool:
            input = pool(input)

        return input

class BNPReLU(nn.Module):
    def __init__(self, nIn):
        super().__init__()
        self.bn = nn.BatchNorm2d(nIn, eps=1e-3)
        self.acti = nn.PReLU(nIn)

    def forward(self, input):
        output = self.bn(input)
        output = self.acti(output)

        return output



class LEDNet(nn.Module):
    def __init__(self, classes):
        super().__init__()
        
        self.initial_block = DownsamplerBlock(3,32)
        self.attn = LSHSelfAttention(dim = 128, heads = 1, bucket_size = 30, n_hashes = 4, causal = False)
        self.out_conv = nn.Conv2d(32, classes, kernel_size=3, padding =1)
#        self.out_small = nn.Conv2d(64, 5, kernel_size=3, padding =1)
        self.out_small = nn.Conv2d(64, 1, kernel_size=3, padding=1)
        self.SA = SpatialAttention(128, 64, 64, 128)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=1)
#        self.CA1 = CoordAtt(32, 32, reduction=32)
#        self.bn_prelu_4 = BNPReLU(64)
        self.SA2 = SpatialAttention(64, 32, 32, 64)
#        self.ffm = FeatureFusionModule(96, 64)

        
        self.layers1 = nn.ModuleList()
        self.layers2 = nn.ModuleList()
        self.layers3 = nn.ModuleList()

        for x in range(0, 3):   
           self.layers1.append(FEM_A(32, 0, 1))
        

        self.down2 = DownsamplerBlock(32, 64)
          
        for x in range(0, 2):   
           self.layers2.append(FEM_A(64, 0, 1))
  
        self.down3 = DownsamplerBlock(64, 128)

        for x in range(0, 1):
            self.layers3.append(FEM_A(128, 0, 2))
            self.layers3.append(FEM_A(128, 0, 5))
            self.layers3.append(FEM_A(128, 0, 9))
        for x in range(0, 1):
            self.layers3.append(FEM_A(128, 0, 2))
            self.layers3.append(FEM_A(128, 0, 5))
            self.layers3.append(FEM_A(128, 0, 9))
            self.layers3.append(FEM_A(128, 0, 17))
        

    def forward(self, input):
        
        output_1 = self.initial_block(input)

        for layera in self.layers1:
            output_1 = layera(output_1)

        out_down2 = self.down2(output_1)
        for layerb in self.layers2:
            out_down2 = layerb(out_down2)
        
        out_down3 = self.down3(out_down2)
        for layerc in self.layers3:
            out_down3 = layerc(out_down3)

        
       # b, c, h, w = out_down3.size()
       # feat = out_down3.view(b, c, -1)
       # feat = feat.permute(0, 2, 1)
       # feat_att = self.attn(feat)
        #feat_att = feat_att.permute(0, 2, 1)
        #featatt_ = feat_att.view(b, -1, h, w)
        #output_ = out_down3 + featatt_
       
        #out_att = self.SA(out_down2, output_)

        #outlast = self.SA2(output_1, out_att)
        #out_last = self.out_conv(outlast)
        #out_small = self.out_small(out_down2)

        
        out = F.interpolate(out_down3, [512,1024], mode="bilinear", align_corners=True)
#        small = F.interpolate(out_small, input.size()[2:], mode="bilinear", align_corners=True)
        #print(out.shape

        return out

         

"""print layers and params of network"""
if __name__ == '__main__':
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = LEDNet(classes=19).to(device)
    summary(model,(3, 512, 1024))
