from model.LEDNet import LEDNet


def build_model(model_name, num_classes):
    if model_name == 'LEDNet':
        return LEDNet(classes=num_classes)
