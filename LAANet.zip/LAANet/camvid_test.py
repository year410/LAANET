###########################################################################
# Created by: Tianyi Wu
# Email: wutianyi@ict.ac.cn 
# Copyright (c) 2018
###########################################################################
import os
import time
import torch
import pickle
import timeit
import random
import numpy as np
import torch.nn as nn
from torch.utils import data
from argparse import ArgumentParser
from torch.autograd import Variable
import torch.backends.cudnn as cudnn
import torchvision.transforms as transforms
import torchvision.utils as TF
#torchvision.utils
import shutil
#import tensorflow as tf
#import matplotlib.pyplot as plt
#user
#from model import CGNet
#from model import DABNet
#from model import BianJiema
from model import LEDNet_oursvi
from tools.metric import get_iou
from tools.modeltools import netParams
from tools.loss import CrossEntropyLoss2d
from tools.convert_state import convert_state_dict
from  dataset.camvid import CamVidDataSet,CamVidValDataSet, CamVidTrainInform
from utils.utils import save_predict

def test(args, test_loader, model, criterion):
    """
    args:
      val_loader: loaded for validation dataset
      model: model
      criterion: loss function
    return: class IoU and mean IoU
    """
    #evaluation or test mode
    model.eval()
    total_batches = len(test_loader)
   
    data_list=[]
    for i, (input, label, size, name) in enumerate(test_loader):
        input_var = Variable(input, volatile=True).cuda()
        output,small = model(input_var)
        
        
        """image0s = vi1.squeeze(dim = 0)
        print('11111111111111', image0s.size())
        image0s = image0s.cpu().detach().numpy()
        
        shutil.rmtree('new_feature_picture0/')
        os.mkdir('new_feature_picture0/')
        image0s=torch.split(image0s,1,dim=0)
        k=0
        for image0 in image0s:
           # q=0
            #image0=torch.split(image0,1,dim=1)
            #for i in image0:
            t='backbone-64-416-416-picture'+str(k)+'-channel-'+str(k)+'.jpg'
            TF.save_image(image0,os.path.join('new_feature_picture0',t))
            #q=q+1
            k=k+1  
        fig=plt.figure(figsize=(6, 4))
        n=1
# 一层中不同通道的图片
        for i in range(1):
            for j in range(1):
                idx=n*i+j
                ax=fig.add_subplot(n,n,idx+1)
                ax.imshow(image0s[idx,:,:])
                plt.savefig('./4compose_atten1.jpg')"""

        
        
        output= output.cpu().data[0].numpy()
        gt = np.asarray(label[0].numpy(), dtype = np.uint8)
        output= output.transpose(1,2,0)
        output= np.asarray(np.argmax(output, axis=2), dtype=np.uint8)
        data_list.append( [gt.flatten(), output.flatten()])
        
        save_predict(output, gt, name[0], args.dataset, args.save_seg_dir,
                output_grey=False, output_color=True, gt_color=False)
        
    meanIoU, per_class_iu= get_iou(data_list, args.classes)
    return meanIoU, per_class_iu

def test_model(args):
    """
    main function for testing 
    args:
       args: global arguments
    """
    print("=====> Check if the cached file exists ")
    if not os.path.isfile(args.inform_data_file):
        print("%s is not found" %(args.inform_data_file))
        dataCollect = CamVidTrainInform(args.data_dir, args.classes, train_set_file= args.dataset_list, 
                                        inform_data_file = args.inform_data_file) #collect mean std, weigth_class information
        datas = dataCollect.collectDataAndSave()
        if datas is None:
            print('Error while pickling data. Please check.')
            exit(-1)
    else:
        print("%s exists" %(args.inform_data_file))
        datas = pickle.load(open(args.inform_data_file, "rb"))
    
    print(args)
    global network_type
     
    if args.cuda:
        print("=====> Use gpu id: '{}'".format(args.gpus))
        os.environ["CUDA_VISIBLE_DEVICES"] = args.gpus
        if not torch.cuda.is_available():
            raise Exception("No GPU found or Wrong gpu id, please run without --cuda")
    
    args.seed = 1234
    print("Random Seed: ", args.seed)
    torch.manual_seed(args.seed)
    if args.cuda:
        torch.cuda.manual_seed(args.seed) 
    cudnn.enabled = True

    M = args.M
    N = args.N
#    model = CGNet.Context_Guided_Network(classes= args.classes, M= M, N= N)
    model = LEDNet_oursvi.LEDNet(classes= args.classes)
    if not os.path.exists(args.save_seg_dir):
            os.makedirs(args.save_seg_dir)
    network_type="LEDNet"
    print("=====> current architeture:  LEDNet")
    total_paramters = netParams(model)
    print("the number of parameters: " + str(total_paramters))
    print("data['classWeights']: ", datas['classWeights'])
    weight = torch.from_numpy(datas['classWeights'])
    print("=====> Dataset statistics")
    print("mean and std: ", datas['mean'], datas['std'])
    
    # define optimization criteria
    criteria = CrossEntropyLoss2d(weight, args.ignore_label)
#    n_min = args.batch_size * 360 * 480 // 4
#    criteria = OhemCELoss(thresh=0.7, n_min=n_min, ignore_lb= args.ignore_label)

    if args.cuda:
        model = model.cuda()
        criteria = criteria.cuda()
    
    #load test set
    train_transform= transforms.Compose([
        transforms.ToTensor()])
    testLoader = data.DataLoader(CamVidValDataSet(args.data_dir, args.test_data_list,f_scale=1,  mean= datas['mean']),
                                  batch_size = args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True, drop_last=True)

    if args.resume:
        if os.path.isfile(args.resume):
            print("=====> loading checkpoint '{}'".format(args.resume))
            checkpoint = torch.load(args.resume)
            #model.load_state_dict(convert_state_dict(checkpoint['model']))
            model.load_state_dict(checkpoint['model'])
        else:
            print("=====> no checkpoint found at '{}'".format(args.resume))
    
    cudnn.benchmark= True

    print("=====> beginning test")
    print("length of test set:", len(testLoader))
    mIOU_test, per_class_iu = test(args, testLoader, model, criteria)
    print("mIou", mIOU_test)
    print(per_class_iu)

if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--model', type = str, default = "LEDNet", help = "model name: Context Guided Network")
    parser.add_argument('--dataset', type = str, default = "camvid", help = "camvid or cityscapes")
    parser.add_argument('--ignore_label', type = int, default = 255, help = "nClass")
    parser.add_argument('--data_dir', default = "./dataset/camvid", help = "data directory")
    parser.add_argument('--test_data_list', default = "./dataset/camvid/camvid_test_list.txt", help= "data directory")
    parser.add_argument('--scaleIn', type = int, default = 1, help = "for input image, default is 1, keep fixed size")  
    parser.add_argument('--num_workers', type = int, default = 1, help = "the number of parallel threads") 
    parser.add_argument('--batch_size', type = int, default = 1, help = "the batch size is set to 1 when testing")
    parser.add_argument('--resume', type = str, default = "./checkpoint/model_1201.pth", 
                         help = "use this file to load last checkpoint for testing")
    parser.add_argument('--classes', type = int, default = 11, 
                         help = "the number of classes in the dataset. 19 and 11 for cityscapes and camvid, respectively")
    parser.add_argument('--save_seg_dir', type=str, default="./result_ours/",
                        help="saving path of prediction result")
    parser.add_argument('--inform_data_file', default = "./dataset/inform/camvid_inform.pkl", 
                         help = "storing classes weights, mean and std")
    parser.add_argument('--M', type = int, default = 3,  help = "the number of block in stage 2")
    parser.add_argument('--N', type = int, default = 21, help = "the number of block in stage 3")
    parser.add_argument('--cuda', type = bool, default = True, help = "running on CPU or GPU")
    parser.add_argument("--gpus", type = str, default = "0",  help = "gpu ids (default: 0)")
    parser.add_argument("--gpu_nums",  type = int, default=1 , help="the number of gpu")
    args = parser.parse_args()
    test_model(args)


