###########################################################################
# Created by: Tianyi Wu
# Email: wutianyi@ict.ac.cn 
# Copyright (c) 2018
###########################################################################
import os
import time
import torch
import timeit
import pickle
import random
import numpy as np
import matplotlib.pyplot as plt
import torch.nn as nn
from torch.utils import data
from torch.autograd import Variable
import torch.backends.cudnn as cudnn
import torchvision.transforms as transforms
from argparse import ArgumentParser
#user
#from model import CGNet  # network
#from model import ERFNet
#from model import LEDNet_ori
#from model import DABNet
#from model import FBSNet
from model import BianJiema
from tools.metric import get_iou
from tools.modeltools import netParams
from tools.loss import CrossEntropyLoss2d # loss function
from utils.lr_scheduler import WarmupPolyLR
#from object_loss import SmallObjectLoss
from tools.convert_state import convert_state_dict
from dataset.camvid import CamVidDataSet,CamVidValDataSet, CamVidTrainInform  #dataset

os.environ["CUDA_VISIBLE_DEVICES"] = "1"

def val(args, val_loader, model, criterion):
    """
    args:
      val_loader: loaded for validation dataset
      model: model
      criterion: loss function
    return: IoU class, and mean IoU
    """
    #evaluation mode
    model.eval()
    total_batches = len(val_loader)
   
    data_list=[]
    for i, (input, label, size, name) in enumerate(val_loader):
        start_time = time.time()
        with torch.no_grad():
            input_var = Variable(input).cuda()
        output = model(input_var)
        time_taken = time.time() - start_time
        print("[%d/%d]  time: %.2f" % (i, total_batches, time_taken))
        output= output.cpu().data[0].numpy()
#        smallobj= smallobj.cpu().data[0].numpy()

        gt = np.asarray(label[0].numpy(), dtype = np.uint8)
        #print("222222222222", gt)
        output= output.transpose(1,2,0)
#        smallobj = smallobj.transpose(1,2,0)
        output= np.asarray(np.argmax(output, axis=2), dtype=np.uint8)
        data_list.append( [gt.flatten(), output.flatten()])

    meanIoU, per_class_iu= get_iou(data_list, args.classes)
    return meanIoU, per_class_iu

def adjust_learning_rate( args, cur_epoch, max_epoch, curEpoch_iter, perEpoch_iter, baselr):
    """
    poly learning stategyt
    lr = baselr*(1-iter/max_iter)^power
    """
    cur_iter = cur_epoch*perEpoch_iter + curEpoch_iter
    max_iter=max_epoch*perEpoch_iter
    lr = baselr*pow( (1 - 1.0*cur_iter/max_iter), 0.9)

    return lr


def train(args, train_loader, model, criterion, optimizer, epoch):
    """
    args:
       train_loader: loaded for training dataset
       model: model
       criterion: loss function
       optimizer: optimization algorithm, such as ADAM or SGD
       epoch: epoch number
    return: average loss, per class IoU, and mean IoU
    """
    model.train()
    epoch_loss = []

    data_list=[]
    total_batches = len(train_loader)
    print("=====> the number of iterations per epoch: ", total_batches)
   # small_loss = SmallObjectLoss()
    for iteration, batch in enumerate( train_loader, 0 ):
        args.per_iter = total_batches
        args.max_iter = args.max_epochs * total_batches
        args.cur_iter = epoch * total_batches + iteration
        
        scheduler = WarmupPolyLR(optimizer, T_max=args.max_iter, cur_iter=args.cur_iter, warmup_factor=1.0 / 3,
                                 warmup_iters=250, power=0.9)
        lr = optimizer.param_groups[0]['lr']

        
        start_time = time.time()
        images, labels, _, _ = batch
        images = Variable( images ).cuda()
        labels = Variable( labels.long() ).cuda()
     
        output = model( images )
#        print('output',output.size())
#        print('labels',labels.size())
        loss = criterion(output, labels)
        #losss = small_loss(smallobj, labels)
        #loss = loss1 
        optimizer.zero_grad()  #set the grad to zero
        loss.backward()
        optimizer.step()
        epoch_loss.append( loss.item() )
        time_taken = time.time() - start_time
        
        gt = np.asarray( labels.cpu().data[0].numpy(), dtype = np.uint8 )
        output = output.cpu().data[0].numpy()
        output = output.transpose(1,2,0)
        output = np.asarray( np.argmax(output, axis=2), dtype=np.uint8 )

        data_list.append( [gt.flatten(), output.flatten()] )
        
#        if total_batches % 46 ==0:
        
#        print('=====> epoch[%d/%d] iter: (%d/%d) \tcur_lr: %.6f loss: %.3f time:%.2f' % ( epoch, args.max_epochs, iteration, 
#              total_batches, lr,loss.item()   ,time_taken ) )

    average_epoch_loss_train = sum( epoch_loss ) / len( epoch_loss )
    meanIoU, per_class_iu = get_iou( data_list, args.classes )

    return average_epoch_loss_train, per_class_iu, meanIoU, lr

def train_model(args):
    """
    args:
       args: global arguments
    """
    h, w = map(int, args.input_size.split(','))
    input_size = (h, w)
    print("=====> checking if inform_data_file exists")
    if not os.path.isfile(args.inform_data_file):
        print("%s is not found" %( args.inform_data_file ) )
        dataCollect = CamVidTrainInform(args.data_dir, args.classes, train_set_file = args.dataset_list, 
                                        inform_data_file = args.inform_data_file) #collect mean std, weigth_class information
        datas = dataCollect.collectDataAndSave()
        if datas is None:
            print("error while pickling data. Please check.")
            exit(-1)
    else:
        print("find file: ", str(args.inform_data_file))
        datas = pickle.load( open( args.inform_data_file, "rb") )
    
    print(args)
    global network_type
     
    if args.cuda:
        print("=====> use gpu id: '{}'".format(args.gpus))
        os.environ["CUDA_VISIBLE_DEVICES"] = args.gpus
        if not torch.cuda.is_available():
            raise Exception("No GPU found or Wrong gpu id, please run without --cuda")
    
    args.seed = 1234
    print("====> Random Seed: ", args.seed)
    torch.manual_seed(args.seed)
    if args.cuda:
        torch.cuda.manual_seed(args.seed) 
    
    cudnn.enabled = True
    M = args.M
    N = args.N
    print("=====> building network")
#    model = CGNet.Context_Guided_Network(classes= args.classes, M= M, N= N)
    model = BianJiema.LEDNet(classes= args.classes)
    network_type="LEDNet"
    print("=====> current architeture:  LEDNet")
    
    print("=====> computing network parameters")
    total_paramters = netParams(model)
    print("the number of parameters: " + str(total_paramters))
    
    print("data['classWeights']: ", datas['classWeights'])
    print('=====> Dataset statistics')
    print('mean and std: ', datas['mean'], datas['std'])
    
    # define optimization criteria
    weight = torch.from_numpy(datas['classWeights'])
    criteria = CrossEntropyLoss2d(weight, args.ignore_label)

#    n_min = args.batch_size * 360 * 480 // 4
#    criteria = OhemCELoss(thresh=0.7, n_min=n_min, ignore_lb= args.ignore_label)
    

    if args.cuda:
        criteria = criteria.cuda()
        args.gpu_nums = 1
        if torch.cuda.device_count()>1:
            print("torch.cuda.device_count()=",torch.cuda.device_count())
            args.gpu_nums = torch.cuda.device_count()
            model = torch.nn.DataParallel(model).cuda()
        else:
            print("single GPU for training")
            model = model.cuda()  
    
    args.savedir = ( args.savedir + args.dataset + '/'+ 'FEEA_A_r4_' + 'bs' 
                    + str(args.batch_size)+ "_"+str(args.train_type)+'/')
    if not os.path.exists(args.savedir):
        os.makedirs(args.savedir)

    #Data augmentation, compose the data with transforms
    train_transform= transforms.Compose([
        transforms.ToTensor()])
    trainLoader = data.DataLoader( CamVidDataSet( args.data_dir, args.train_data_list, crop_size = input_size, scale = args.random_scale, 
                                                      mirror = args.random_mirror, mean = datas['mean'] ),
                                   batch_size = args.batch_size, shuffle = True, num_workers = args.num_workers, 
                                   pin_memory = True, drop_last = True )
    valLoader = data.DataLoader( CamVidValDataSet( args.data_dir, args.val_data_list,f_scale = 1,  mean = datas['mean']),
                                 batch_size = 1, shuffle = True, num_workers = args.num_workers, pin_memory = True, drop_last = True )

    start_epoch = 0
    if args.resume:
        if os.path.isfile(args.resume):
            checkpoint = torch.load(args.resume)
            start_epoch = checkpoint['epoch']
            model.load_state_dict(checkpoint['model'])
            #model.load_state_dict(convert_state_dict(checkpoint['model']))
            print("=====> loading checkpoint '{}' (epoch {})".format(args.resume, checkpoint['epoch']))
        else:
            print("=====> no checkpoint found at '{}'".format(args.resume))
    
    model.train()
    cudnn.benchmark= True
    
    logFileLoc = args.savedir + args.logFile
    if os.path.isfile(logFileLoc):
        logger = open(logFileLoc, 'a')
    else:
        logger = open(logFileLoc, 'w')
        logger.write("Parameters: %s" % (str(total_paramters)))
        logger.write("\n%s\t\t%s\t\t%s\t\t%s\t\t%s\t\t" % ('Epoch', 'Loss(Tr)', 'Loss(val)', 'mIOU (tr)', 'mIOU (val)'))
    logger.flush()

    optimizer = torch.optim.Adam(model.parameters(), args.lr, (0.9, 0.999), eps=1e-08, weight_decay=1e-4)
    
    lossTr_list = []
    epoches = []
    mIOU_val_list = []
    
    print('=====> beginning training')
    for epoch in range(start_epoch, args.max_epochs):
        #training
        lossTr, per_class_iu_tr, mIOU_tr, lr = train(args, trainLoader, model, criteria, optimizer, epoch)
        lossTr_list.append(lossTr)
        
        #validation
        if epoch % 100 ==0:
            epoches.append(epoch)
            mIOU_val, per_class_iu = val(args, valLoader, model, criteria)
            mIOU_val_list.append(mIOU_val)
            logger.write("\n%d\t\t%.4f\t\t%.4f\t\t%.4f\t\t%.7f" % (epoch, lossTr, mIOU_tr, mIOU_val, lr))
            logger.flush()
            print("epoch: " + str(epoch) + ' Details')
            print("\nEpoch No.: %d\tTrain Loss = %.4f\t mIOU(tr) = %.4f\t mIOU(val) = %.4f\t lr= %.6f" % (epoch,
                   lossTr, mIOU_tr, mIOU_val, lr))
        else:
            logger.write("\n%d\t\t%.4f\t\t%.4f\t\t%.7f" % (epoch, lossTr, mIOU_tr, lr))
            logger.flush()
            print("Epoch : " + str(epoch) + ' Details')
            print("\nEpoch No.: %d\tTrain Loss = %.4f\t mIOU(tr) = %.4f\t lr= %.6f" % (epoch, lossTr, mIOU_tr, lr))
        
        #save the model
        model_file_name = args.savedir +'/model_' + str(epoch + 1) + '.pth'
        state = {"epoch": epoch+1, "model": model.state_dict()}
        if epoch > args.max_epochs - 5:
            torch.save(state, model_file_name)
        elif not epoch % 100:
            torch.save(state, model_file_name)
            
        # draw plots for visualization
        if epoch % 50 == 0 or epoch == (args.max_epochs - 1):
            # Plot the figures per 50 epochs
            fig1, ax1 = plt.subplots(figsize=(11, 8))

            ax1.plot(range(start_epoch, epoch + 1), lossTr_list)
            ax1.set_title("Average training loss vs epochs")
            ax1.set_xlabel("Epochs")
            ax1.set_ylabel("Current loss")

            plt.savefig(args.savedir + "loss_vs_epochs.png")

            plt.clf()

            fig2, ax2 = plt.subplots(figsize=(11, 8))

            ax2.plot(epoches, mIOU_val_list, label="Val IoU")
            ax2.set_title("Average IoU vs epochs")
            ax2.set_xlabel("Epochs")
            ax2.set_ylabel("Current IoU")
            plt.legend(loc='lower right')

            plt.savefig(args.savedir + "iou_vs_epochs.png")

            plt.close('all')

    logger.close()

if __name__ == '__main__':
    start = timeit.default_timer()
    parser = ArgumentParser()
    parser.add_argument('--model', default = "LEDNet", help = "model name: LEDNet")
    parser.add_argument('--dataset', default = "camvid", help = "dataset: cityscapes or camvid")
    parser.add_argument('--ignore_label', type = int,  default = -1, help = "nClass")
    parser.add_argument('--data_dir', default = "./dataset/camvid", help ='data directory')
    parser.add_argument('--dataset_list', default = "camvid_trainval_list.txt",
                        help = "train and val data, for computing the ration of all kinds, mean and std")
    parser.add_argument('--train_data_list', default = "./dataset/camvid/camvid_train_list.txt", help = "train set")
    parser.add_argument('--train_type', type = str, default = "ontrain", 
                         help = "ontrain for training on train set, ontrainval for training on train+val set")
    parser.add_argument('--max_epochs', type = int, default = 1000, help = "the number of epochs: 800 for train+val set")
    parser.add_argument('--val_data_list', default = "./dataset/camvid/camvid_val_list.txt", help = "val set")
    parser.add_argument('--scaleIn', type = int, default = 1, help = "for input image, default is 1, keep fixed size")  
    parser.add_argument('--input_size', type = str, default = "360,480", help = "input size of model") 
    parser.add_argument('--random_mirror', type = bool, default = True, help = "input image random mirror") 
    parser.add_argument('--random_scale', type = bool, default = True, help = "input image resize 0.5 to 2") 
    parser.add_argument('--num_workers', type = int, default = 0, help = " the number of parallel threads") 
    parser.add_argument('--batch_size', type = int, default = 12, help = "the batch size is set to 16 for 2 GPUs")

    parser.add_argument('--lr', type = float, default = 1e-3, help = "initial learning rate")
    parser.add_argument('--savedir', default = "./checkpoint/", help = "directory to save the model snapshot")
    parser.add_argument('--resume', type = str, default = "", 
                         help = "use this file to load last checkpoint for continuing training")  
    parser.add_argument('--classes', type = int, default = 11, 
                         help = "the number of classes in the dataset. 19 and 11 for cityscapes and camvid, respectively")
    parser.add_argument('--inform_data_file', default = "./dataset/camvid_inform.pkl", 
                         help = "saving statistic information of the dataset (train+val set), classes weigtht, mean and std")
    parser.add_argument('--M', type = int, default = 3, help = "the number of blocks in stage 2")
    parser.add_argument('--N', type = int, default = 21, help = "the number of blocks in stage 3")
    parser.add_argument('--logFile', default= "log.txt", help = "storing the training and validation logs")
    parser.add_argument('--cuda', type = bool, default = True, help = "running on CPU or GPU")
    parser.add_argument('--gpus', type = str, default = "1", help = "default GPU devices (0,1)")
    args = parser.parse_args()
    train_model(args)
    end = timeit.default_timer()
    print("training time:", 1.0*(end-start)/3600)

