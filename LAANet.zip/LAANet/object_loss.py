
import torch
from torch import nn
from torch.nn import functional as F
import cv2
import numpy as np
import json

def dice_loss_func(input, target):
    smooth = 1.  #用于防止分母为零
    sigmoid = torch.nn.Sigmoid()
    input = sigmoid(input)
    n = input.size(0)   #input是包含batchsize的维度为4的张量，n为batchsize的值
    iflat = input.view(n, -1)  #view函数就是reshape操作，对张量进行维度转换，reshape成n*(c*h*w)二维
#    tflat = target.contiguous().view(n, -1)
    tflat = target.view(n, -1)
    intersection = (iflat * tflat).sum(1)
    loss = 1 - ((2. * intersection + smooth) / (iflat.sum(1) + tflat.sum(1) + smooth))

    return loss.mean()

class MulticlassDiceLoss(nn.Module):
    def __init__(self, weights=[0,1,1,1,1,1], *args, **kwargs):
        super(MulticlassDiceLoss, self).__init__()
	
    def forward(self, input, target):

        C = 6
        weights = [0,1,1,1,1,1]
#        weights = np.array(weights)
#        dice = dice_loss_func()
#        weights = self.weights
        totalLoss=0.
        for i in range(C):
            diceLoss = dice_loss_func(input[:,i], target[:,i])
            diceLoss *= weights[i]
            totalLoss += diceLoss

        return totalLoss



def get_one_hot(label, N):
    size = list(label.size())
    label = label.view(-1)   # reshape 为向量
    ones = torch.sparse.torch.eye(N).cuda()
    ones = ones.index_select(0, label.long())   # 用上面的办法转为换one hot
    size.append(N)  # 把类别输目添到size的尾后，准备reshape回原来的尺寸
    
    return ones.view(*size)

def Dice_loss(inputs, target, beta=1, smooth = 1e-5):
    n, c, h, w = inputs.size()
    nt, ht, wt, ct = target.size()
        
    temp_inputs = torch.softmax(inputs.transpose(1, 2).transpose(2, 3).contiguous().view(n, -1, c),-1)
    temp_target = target.view(n, -1, ct)
 
    #--------------------------------------------#
    #   计算dice loss
    #--------------------------------------------#
    tp = torch.sum(temp_target[...,:-1] * temp_inputs, axis=[0,1])
    fp = torch.sum(temp_inputs                       , axis=[0,1]) - tp
    fn = torch.sum(temp_target[...,:-1]              , axis=[0,1]) - tp
 
    score = ((1 + beta ** 2) * tp + smooth) / ((1 + beta ** 2) * tp + beta ** 2 * fn + fp + smooth)
    dice_loss = 1 - torch.mean(score)
    return dice_loss


class SmallObjectLoss(nn.Module):
    def __init__(self, *args, **kwargs):
        super(SmallObjectLoss, self).__init__()
        
#        self.SmallLoss = MulticlassDiceLoss(weights = [0,1,1,1,1,1])

    def forward(self, small_logits, gtmasks):
        small_targets = gtmasks
        #choice_list = [0,1,3,4,5,8, -1] 
        choice_list = [0, 1, 2, 3, 8, 9, 10, 11, 13, 14, 15, 16, 255]
        zero = torch.zeros_like(small_targets)
        one = torch.ones_like(small_targets)
        two_five = zero - one
        for idx, c in enumerate(choice_list):        
            small_targets = torch.where(small_targets == c, zero, small_targets)  
           

        zero = torch.zeros_like(small_targets)
        two = one*2
        three = one*3
        four = one*4
        five = one*5
        
        #figure_list = [2, 5, 7, 9, 10]
        figure_list = [4, 5, 6, 7, 12, 17, 18]
        for idx, d in enumerate(figure_list):
            small_targets = torch.where(small_targets == d, one, small_targets)
 

        if small_logits.shape[-1] != small_targets.shape[-1]:
            small_logits = F.interpolate(
                small_logits, small_targets.shape[2:], mode='bilinear', align_corners=True)
#        small_targets = torch.nn.functional.one_hot(small_targets)
#        lost = [0,1,2,3,4]
#        for idx, b in enumerate(lost):
#        small_targets = torch.where(small_targets != -1)
#        small_targets = torch.as_tensor(small_targets)
#        small_targets = get_one_hot(small_targets, 6)
#        small_targets = small_targets.permute(0, 3, 1, 2)
        small_targets2 = torch.unsqueeze(small_targets, 1)

        active_func = nn.Sigmoid()
        small_logits1 = active_func(small_logits)
#        small_targets2 = Variable( small_targets2.long() ).cuda()
        small_targets2 = small_targets2.to(torch.float)
        loss = nn.BCELoss()
        bce_loss = loss(small_logits1, small_targets2)
        dice_loss = dice_loss_func(small_logits, small_targets)
        SmallObjectLoss = dice_loss + bce_loss
        
        return SmallObjectLoss

    def get_params(self):
        wd_params, nowd_params = [], []
        for name, module in self.named_modules():
                nowd_params += list(module.parameters())
        return nowd_params
        


